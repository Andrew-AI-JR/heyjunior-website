LinkedIn Automation Tool
=====================

Welcome to the LinkedIn Automation Tool! This tool helps you automate your LinkedIn engagement while maintaining a natural and professional presence.

BETA TESTING DISCLAIMER:
-----------------------
This software is currently in beta testing phase. By using this software, you acknowledge that:
1. This is a pre-release version and may contain bugs or issues
2. Features may change without notice
3. The software is provided "as is" without warranty of any kind
4. We recommend using this version in a controlled environment
5. Please report any issues or feedback to help improve the software

Quick Start Guide:
-----------------
1. Extract all files from this ZIP to a folder on your computer
2. Open Terminal and navigate to the extracted folder
3. Run: chmod +x linkedin_automation
4. Run: ./linkedin_automation
5. Enter your LinkedIn credentials when prompted
6. Enter your professional bio and keywords when prompted
7. The tool will automatically:
   - Search for relevant posts
   - Generate personalized comments using Llama 3.2
   - Verify and edit comments for authenticity
   - Engage with content in your industry

Features:
---------
✓ Smart post searching
✓ AI-powered comment generation with Llama 3.2
✓ Natural engagement patterns
✓ Comment verification and editing
✓ Secure credential storage
✓ Automatic updates

System Requirements:
------------------
- macOS 10.15 or later
- Google Chrome browser
- Internet connection
- Valid LinkedIn account
- Ollama with Llama 3.2 model installed

Common Questions:
----------------
Q: Is this safe to use?
A: Yes, the tool follows LinkedIn's guidelines and uses natural engagement patterns.

Q: Will this affect my account?
A: No, the tool is designed to maintain your account's safety and reputation.

Q: How often should I use it?
A: We recommend using it 2-3 times per week for best results.

Troubleshooting:
---------------
If you encounter any issues:
1. Make sure Chrome is installed and up to date
2. Check your internet connection
3. Verify your LinkedIn credentials
4. Ensure Ollama is running with Llama 3.2 model
5. Restart the application
6. If you get a security warning, go to System Preferences > Security & Privacy and allow the app

Support:
--------
For any issues or questions, please contact:
amalinow1973@gmail.com

Tips for Best Results:
---------------------
1. Keep your keywords relevant to your industry
2. Don't run the tool too frequently
3. Review the generated comments before posting
4. Keep your Chrome browser updated
5. Ensure your user bio is up to date

Note: The tool will automatically check for updates when you run it.

HeyJunior™ - All Rights Reserved
