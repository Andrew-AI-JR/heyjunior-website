# LinkedIn Automation Tool - Private Repository

🔒 **This is a private repository containing the source code for the LinkedIn Automation Tool.**

## 📋 Overview

This repository contains the complete source code for the LinkedIn Automation Tool, including:

- **Desktop Application**: GUI-based LinkedIn automation tool
- **Backend API**: FastAPI-based backend service
- **Build Scripts**: Cross-platform build automation
- **Tests**: Comprehensive test suite

## 🏗️ Project Structure

```
linkedin-automation-tool/
├── backend-api/              # FastAPI backend service
│   ├── src/                  # Source code
│   ├── tests/                # Backend tests
│   └── docs/                 # API documentation
├── src/                      # Main application source
├── core/                     # Core AI services
├── scripts/                  # Utility scripts
├── tests/                    # Application tests
├── linkedin_commenter.py     # Main automation script
├── linkedin_automation_gui.py # GUI application
├── build_executable.py      # Windows build script
├── build_macos.py           # macOS build script
├── windows_installer.py     # Windows installer
├── macos_installer.py       # macOS installer
└── requirements*.txt        # Dependencies
```

## 🚀 Quick Start

### Prerequisites

- Python 3.8+
- Chrome browser
- Git

### Installation

1. **Clone the repository**:
   ```bash
   git clone <private-repo-url>
   cd linkedin-automation-tool
   ```

2. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

3. **Configure environment**:
   ```bash
   cp dc.env.example .env
   # Edit .env with your configuration
   ```

4. **Run the application**:
   ```bash
   python linkedin_automation_gui.py
   ```

## 🔧 Development

### Backend API

```bash
cd backend-api
pip install -r requirements.txt
uvicorn src.backend_api.main:app --reload
```

### Running Tests

```bash
# Run all tests
python -m pytest tests/

# Run specific test file
python -m pytest tests/test_linkedin_login.py
```

### Building Executables

**Windows**:
```bash
python build_executable.py
```

**macOS**:
```bash
python build_macos.py
```

## 📦 Build System

### Windows Build
- Creates standalone `.exe` file
- Includes all dependencies
- Generates installer package

### macOS Build
- Creates universal binary (Intel + Apple Silicon)
- Generates `.app` bundle
- Creates `.dmg` installer

## 🧪 Testing

The project includes comprehensive tests:

- **Unit Tests**: Core functionality testing
- **Integration Tests**: API endpoint testing
- **E2E Tests**: Full workflow testing

## 🔐 Security

- All sensitive data is encrypted
- API keys stored securely
- User credentials never logged
- GDPR compliant data handling

## 📚 Documentation

- [API Documentation](backend-api/docs/)
- [Build Instructions](README_macOS_Build.md)
- [Subscription Integration](backend-api/docs/SUBSCRIPTION_INTEGRATION.md)

## 🤝 Contributing

1. Create a feature branch
2. Make your changes
3. Add tests for new functionality
4. Ensure all tests pass
5. Submit a pull request

## 📄 License

This is proprietary software. All rights reserved.

## 🆘 Support

For technical support or questions:
- Create an issue in this repository
- Contact the development team

---

**⚠️ Important**: This repository contains proprietary code. Do not share or distribute without authorization.
