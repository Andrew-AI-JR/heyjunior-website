#!/usr/bin/env python3
"""
Test Script for License Management System
Tests the complete license validation flow
"""

import sys
import os
import json
from datetime import datetime

# Add src directory to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

try:
    from license_validator import LicenseValidator
    print("✅ License validator imported successfully")
except ImportError as e:
    print(f"❌ Failed to import license validator: {e}")
    sys.exit(1)

def test_license_validator():
    """Test the license validator functionality."""
    print("\n🔧 Testing License Validator")
    print("=" * 50)
    
    # Initialize validator
    validator = LicenseValidator()
    print(f"✅ License validator initialized")
    print(f"📱 Machine fingerprint: {validator.machine_fingerprint}")
    print(f"🌐 API URL: {validator.api_base_url}")
    
    # Test machine info
    machine_info = validator._get_machine_info()
    print(f"💻 Machine info: {json.dumps(machine_info, indent=2)}")
    
    # Check current license status
    print(f"\n📋 Current License Status:")
    status = validator.get_license_status()
    print(f"   Status: {status['status']}")
    print(f"   Message: {status['message']}")
    
    if status['status'] == 'active':
        print(f"   Features: {status.get('features', [])}")
        print(f"   Expiry: {status.get('expiry_date', 'Unknown')}")
    
    # Test license validation (offline)
    print(f"\n🔍 Testing License Validation (Offline):")
    validation_result = validator.validate_license()
    print(f"   Valid: {validation_result['valid']}")
    
    if not validation_result['valid']:
        print(f"   Error: {validation_result.get('error', 'Unknown error')}")
    else:
        print(f"   Data: {validation_result.get('data', {})}")
    
    # Test online validation (if license exists)
    local_license = validator.load_local_license()
    if local_license and local_license.get('license_key'):
        print(f"\n🌐 Testing Online Validation:")
        try:
            online_result = validator.validate_license_online(local_license['license_key'])
            print(f"   Valid: {online_result['valid']}")
            if not online_result['valid']:
                print(f"   Error: {online_result.get('error', 'Unknown error')}")
        except Exception as e:
            print(f"   Error: {str(e)}")
    else:
        print(f"\n⚠️ No local license found for online validation test")
    
    return validation_result['valid']

def test_gui_integration():
    """Test GUI integration (import only)."""
    print("\n🖥️ Testing GUI Integration")
    print("=" * 50)
    
    try:
        # Test if GUI can import license validator
        import linkedin_automation_gui
        print("✅ GUI module imported successfully")
        
        # Check if LicenseValidator is available in GUI
        if hasattr(linkedin_automation_gui, 'LicenseValidator'):
            print("✅ LicenseValidator available in GUI")
        else:
            print("⚠️ LicenseValidator not directly available in GUI (may be imported conditionally)")
        
        return True
    except ImportError as e:
        print(f"❌ Failed to import GUI: {e}")
        return False

def test_automation_integration():
    """Test automation script integration (import only)."""
    print("\n🤖 Testing Automation Integration")
    print("=" * 50)
    
    try:
        # Test if automation script can import license validator
        import linkedin_commenter
        print("✅ Automation module imported successfully")
        
        # Check if validate_license function exists
        if hasattr(linkedin_commenter, 'validate_license'):
            print("✅ validate_license function available")
        else:
            print("❌ validate_license function not found")
        
        return True
    except ImportError as e:
        print(f"❌ Failed to import automation script: {e}")
        return False

def test_api_connectivity():
    """Test API connectivity."""
    print("\n🌐 Testing API Connectivity")
    print("=" * 50)
    
    try:
        import requests
        
        # Test health endpoint
        api_url = "https://junior-api-915940312680.us-west1.run.app/api/license/health"
        print(f"🔍 Testing: {api_url}")
        
        response = requests.get(api_url, timeout=10)
        
        if response.status_code == 200:
            data = response.json()
            print(f"✅ API health check successful")
            print(f"   Status: {data.get('status', 'Unknown')}")
            print(f"   Service: {data.get('service', 'Unknown')}")
            print(f"   Version: {data.get('version', 'Unknown')}")
            return True
        else:
            print(f"❌ API health check failed: HTTP {response.status_code}")
            return False
            
    except requests.exceptions.RequestException as e:
        print(f"❌ API connectivity error: {str(e)}")
        return False
    except Exception as e:
        print(f"❌ Unexpected error: {str(e)}")
        return False

def main():
    """Run all tests."""
    print("🧪 License Management System Test Suite")
    print("=" * 60)
    print(f"📅 Test Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    
    results = {}
    
    # Run tests
    results['license_validator'] = test_license_validator()
    results['gui_integration'] = test_gui_integration()
    results['automation_integration'] = test_automation_integration()
    results['api_connectivity'] = test_api_connectivity()
    
    # Summary
    print("\n📊 Test Results Summary")
    print("=" * 60)
    
    passed = 0
    total = len(results)
    
    for test_name, result in results.items():
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"{test_name.replace('_', ' ').title()}: {status}")
        if result:
            passed += 1
    
    print(f"\nOverall: {passed}/{total} tests passed")
    
    if passed == total:
        print("🎉 All tests passed! License system is ready.")
        return 0
    else:
        print("⚠️ Some tests failed. Please check the issues above.")
        return 1

if __name__ == "__main__":
    sys.exit(main()) 