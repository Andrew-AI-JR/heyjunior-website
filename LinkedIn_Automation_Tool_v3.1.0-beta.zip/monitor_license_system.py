#!/usr/bin/env python3
"""
License System Monitoring Dashboard
Monitors license validation, payment processing, and system health
"""

import sys
import os
import json
import time
import requests
from datetime import datetime, timedelta
from typing import Dict, List
import threading

# Add src directory to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

try:
    from license_validator import LicenseValidator
except ImportError:
    LicenseValidator = None

class LicenseSystemMonitor:
    """Monitor license system health and performance."""
    
    def __init__(self):
        self.api_base_url = "https://junior-api-915940312680.us-west1.run.app/api"
        self.license_validator = LicenseValidator() if LicenseValidator else None
        self.monitoring_data = {
            "api_health": [],
            "license_validations": [],
            "payment_events": [],
            "errors": []
        }
        self.running = False
    
    def check_api_health(self) -> Dict:
        """Check API health status."""
        try:
            # Test main API health
            response = requests.get(f"{self.api_base_url}/health", timeout=10)
            main_health = {
                "endpoint": "/health",
                "status": response.status_code,
                "response_time": response.elapsed.total_seconds(),
                "timestamp": datetime.now().isoformat()
            }
            
            if response.status_code == 200:
                main_health["data"] = response.json()
            
            # Test license health
            license_response = requests.get(f"{self.api_base_url}/license/health", timeout=10)
            license_health = {
                "endpoint": "/license/health",
                "status": license_response.status_code,
                "response_time": license_response.elapsed.total_seconds(),
                "timestamp": datetime.now().isoformat()
            }
            
            if license_response.status_code == 200:
                license_health["data"] = license_response.json()
            
            return {
                "main_api": main_health,
                "license_api": license_health,
                "overall_status": "healthy" if (response.status_code == 200 and license_response.status_code == 200) else "unhealthy"
            }
            
        except requests.exceptions.RequestException as e:
            return {
                "main_api": {"error": str(e), "timestamp": datetime.now().isoformat()},
                "license_api": {"error": str(e), "timestamp": datetime.now().isoformat()},
                "overall_status": "error"
            }
    
    def test_license_validation(self) -> Dict:
        """Test license validation functionality."""
        if not self.license_validator:
            return {"error": "License validator not available", "timestamp": datetime.now().isoformat()}
        
        try:
            # Test local license status
            status = self.license_validator.get_license_status()
            
            # Test validation (offline)
            validation_result = self.license_validator.validate_license()
            
            return {
                "local_status": status,
                "validation_result": validation_result,
                "machine_fingerprint": self.license_validator.machine_fingerprint,
                "timestamp": datetime.now().isoformat()
            }
            
        except Exception as e:
            return {"error": str(e), "timestamp": datetime.now().isoformat()}
    
    def monitor_payment_system(self) -> Dict:
        """Monitor payment system health."""
        try:
            # Test Stripe connectivity (if we had webhook endpoints)
            # For now, just check if our payment endpoints are accessible
            
            # This would be expanded to include:
            # - Webhook delivery status
            # - Payment success rates
            # - License generation success rates
            
            return {
                "status": "monitoring_not_implemented",
                "note": "Payment monitoring requires webhook integration",
                "timestamp": datetime.now().isoformat()
            }
            
        except Exception as e:
            return {"error": str(e), "timestamp": datetime.now().isoformat()}
    
    def collect_metrics(self) -> Dict:
        """Collect all system metrics."""
        print(f"🔍 Collecting metrics at {datetime.now().strftime('%H:%M:%S')}")
        
        metrics = {
            "timestamp": datetime.now().isoformat(),
            "api_health": self.check_api_health(),
            "license_validation": self.test_license_validation(),
            "payment_system": self.monitor_payment_system()
        }
        
        # Store metrics
        self.monitoring_data["api_health"].append(metrics["api_health"])
        self.monitoring_data["license_validations"].append(metrics["license_validation"])
        self.monitoring_data["payment_events"].append(metrics["payment_system"])
        
        # Keep only last 100 entries
        for key in self.monitoring_data:
            if len(self.monitoring_data[key]) > 100:
                self.monitoring_data[key] = self.monitoring_data[key][-100:]
        
        return metrics
    
    def display_dashboard(self):
        """Display monitoring dashboard."""
        os.system('cls' if os.name == 'nt' else 'clear')
        
        print("🔑 LICENSE SYSTEM MONITORING DASHBOARD")
        print("=" * 60)
        print(f"📅 {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print()
        
        # Get latest metrics
        if self.monitoring_data["api_health"]:
            latest_health = self.monitoring_data["api_health"][-1]
            
            print("🌐 API HEALTH STATUS")
            print("-" * 30)
            
            if "main_api" in latest_health:
                main_status = latest_health["main_api"].get("status", "unknown")
                main_time = latest_health["main_api"].get("response_time", 0)
                print(f"Main API: {'✅' if main_status == 200 else '❌'} HTTP {main_status} ({main_time:.2f}s)")
            
            if "license_api" in latest_health:
                license_status = latest_health["license_api"].get("status", "unknown")
                license_time = latest_health["license_api"].get("response_time", 0)
                print(f"License API: {'✅' if license_status == 200 else '❌'} HTTP {license_status} ({license_time:.2f}s)")
            
            overall = latest_health.get("overall_status", "unknown")
            print(f"Overall: {'✅ Healthy' if overall == 'healthy' else '❌ Unhealthy'}")
            print()
        
        # License validation status
        if self.monitoring_data["license_validations"]:
            latest_license = self.monitoring_data["license_validations"][-1]
            
            print("🔑 LICENSE VALIDATION STATUS")
            print("-" * 30)
            
            if "local_status" in latest_license:
                status = latest_license["local_status"]
                print(f"Local Status: {status.get('status', 'unknown')}")
                print(f"Message: {status.get('message', 'N/A')}")
                
                if status.get('features'):
                    print(f"Features: {', '.join(status['features'])}")
                
                if status.get('expiry_date'):
                    print(f"Expires: {status['expiry_date']}")
            
            if "validation_result" in latest_license:
                validation = latest_license["validation_result"]
                print(f"Validation: {'✅ Valid' if validation.get('valid') else '❌ Invalid'}")
                
                if not validation.get('valid'):
                    print(f"Error: {validation.get('error', 'Unknown')}")
            
            print()
        
        # Statistics
        print("📊 STATISTICS")
        print("-" * 30)
        
        # API health statistics
        healthy_count = sum(1 for h in self.monitoring_data["api_health"] 
                           if h.get("overall_status") == "healthy")
        total_checks = len(self.monitoring_data["api_health"])
        
        if total_checks > 0:
            uptime_percentage = (healthy_count / total_checks) * 100
            print(f"API Uptime: {uptime_percentage:.1f}% ({healthy_count}/{total_checks})")
        
        # License validation statistics
        valid_count = sum(1 for v in self.monitoring_data["license_validations"] 
                         if v.get("validation_result", {}).get("valid"))
        total_validations = len(self.monitoring_data["license_validations"])
        
        if total_validations > 0:
            success_rate = (valid_count / total_validations) * 100
            print(f"License Success Rate: {success_rate:.1f}% ({valid_count}/{total_validations})")
        
        print(f"Total Checks: {total_checks}")
        print(f"Monitoring Duration: {self.get_monitoring_duration()}")
        print()
        
        # Recent errors
        recent_errors = [e for e in self.monitoring_data["errors"] 
                        if datetime.fromisoformat(e["timestamp"]) > datetime.now() - timedelta(hours=1)]
        
        if recent_errors:
            print("⚠️ RECENT ERRORS (Last Hour)")
            print("-" * 30)
            for error in recent_errors[-5:]:  # Show last 5 errors
                timestamp = error["timestamp"][:19]  # Remove microseconds
                print(f"{timestamp}: {error['message']}")
            print()
        
        print("Press Ctrl+C to stop monitoring")
    
    def get_monitoring_duration(self) -> str:
        """Get monitoring duration string."""
        if not self.monitoring_data["api_health"]:
            return "0 minutes"
        
        first_check = datetime.fromisoformat(self.monitoring_data["api_health"][0]["timestamp"])
        duration = datetime.now() - first_check
        
        hours = int(duration.total_seconds() // 3600)
        minutes = int((duration.total_seconds() % 3600) // 60)
        
        if hours > 0:
            return f"{hours}h {minutes}m"
        else:
            return f"{minutes}m"
    
    def log_error(self, message: str):
        """Log an error."""
        error_entry = {
            "message": message,
            "timestamp": datetime.now().isoformat()
        }
        self.monitoring_data["errors"].append(error_entry)
        
        # Keep only last 100 errors
        if len(self.monitoring_data["errors"]) > 100:
            self.monitoring_data["errors"] = self.monitoring_data["errors"][-100:]
    
    def start_monitoring(self, interval: int = 30):
        """Start continuous monitoring."""
        self.running = True
        print(f"🚀 Starting license system monitoring (interval: {interval}s)")
        
        try:
            while self.running:
                try:
                    self.collect_metrics()
                    self.display_dashboard()
                    
                    # Wait for next check
                    for _ in range(interval):
                        if not self.running:
                            break
                        time.sleep(1)
                        
                except KeyboardInterrupt:
                    break
                except Exception as e:
                    self.log_error(f"Monitoring error: {str(e)}")
                    time.sleep(5)  # Wait before retrying
                    
        except KeyboardInterrupt:
            pass
        finally:
            self.running = False
            print("\n🛑 Monitoring stopped")
    
    def stop_monitoring(self):
        """Stop monitoring."""
        self.running = False
    
    def export_metrics(self, filename: str = None):
        """Export monitoring data to JSON file."""
        if not filename:
            filename = f"license_monitoring_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        
        try:
            with open(filename, 'w') as f:
                json.dump(self.monitoring_data, f, indent=2)
            print(f"📁 Metrics exported to {filename}")
        except Exception as e:
            print(f"❌ Failed to export metrics: {e}")

def main():
    """Main monitoring function."""
    print("🔑 License System Monitor")
    print("=" * 40)
    
    monitor = LicenseSystemMonitor()
    
    try:
        # Run initial check
        print("🔍 Running initial system check...")
        metrics = monitor.collect_metrics()
        
        print("\n📊 Initial Status:")
        print(f"API Health: {metrics['api_health']['overall_status']}")
        print(f"License Validation: {'✅' if metrics['license_validation'].get('validation_result', {}).get('valid') else '❌'}")
        
        # Ask user for monitoring mode
        print("\nMonitoring Options:")
        print("1. Continuous monitoring (30s intervals)")
        print("2. Single check and exit")
        print("3. Export current metrics")
        
        choice = input("\nEnter choice (1-3): ").strip()
        
        if choice == "1":
            monitor.start_monitoring(30)
        elif choice == "2":
            monitor.display_dashboard()
        elif choice == "3":
            monitor.export_metrics()
        else:
            print("Invalid choice. Running single check.")
            monitor.display_dashboard()
            
    except KeyboardInterrupt:
        print("\n🛑 Monitoring interrupted")
    except Exception as e:
        print(f"❌ Error: {e}")
    finally:
        monitor.stop_monitoring()

if __name__ == "__main__":
    main() 